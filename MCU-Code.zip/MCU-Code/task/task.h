#ifndef __TASK_H
#define __TASK_H

#include "def.h"
#include "delay.h"

typedef struct _TASK_COMPONENTS
{
	uchar  Run;		//0:
	uchar  Timer;
	uchar  ItvTime;
	void(*TaskHook)(void);
}TASK_COMPONETS;


extern TASK_COMPONETS idata TaskComps[4];


void TaskWave(void);
void TaskSN(void);
void TaskGrear(void);
void TaskBuzzer(void);
void TaskProcess(void);
void strengthchange(uchar stall);  
void check_strength_reply();
void auto_shut_down(void);

/********************************************

*********************************************/		 


#endif