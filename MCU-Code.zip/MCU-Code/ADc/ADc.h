#ifndef __ADC_H
#define __ADC_H
/*****************************/


#define  ADC_FLAG 0x10
void InitADC();
void power_value(void);


#endif