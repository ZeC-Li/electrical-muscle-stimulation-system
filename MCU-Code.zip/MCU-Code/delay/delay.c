#include "delay.h"
#include"intrins.h"
/**************************************/

/*************��ʱ����***********/
/*************************************/ 
void delay(uint num)
{
	char a=10, b=30;
	while(--num)
	     while(--a);
		     while(--b);
}

void delay100ms()		//@11.0592MHz
{
	unsigned char i, j, k;

	_nop_();
	_nop_();
	i = 5;
	j = 52;
	k = 195;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}
