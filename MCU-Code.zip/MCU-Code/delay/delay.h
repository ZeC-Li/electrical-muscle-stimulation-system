#ifndef __DELAY_H
#define __DELAY_H
#include "UART.H"

void delay(uint num);
void delay100ms();

#endif