#ifndef __INT_H
#define __INT_H

#include "def.h"
#include "delay.h"


void Exit0Int(void);
void Exit1Int(void);
void stall_limit();

#endif