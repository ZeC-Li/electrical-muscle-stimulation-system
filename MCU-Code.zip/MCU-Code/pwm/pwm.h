#ifndef __PWM_H
#define __PWM_H

#include "def.h"

extern uint   Pluse_wid; 

void basic_pwm();



#endif