#ifndef __TIMER_H
#define __TIMER_H
#include "UART.H"
#include "def.h"


void  Time0_Init();
void Time1_Init();
void TaskRemarks(void);




#endif